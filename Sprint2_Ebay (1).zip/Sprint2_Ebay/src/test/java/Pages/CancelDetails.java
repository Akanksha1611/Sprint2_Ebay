package Pages;

public class CancelDetails {
	public static void clickCancel()
	{
		locaters.Locaters.seeCancelDetails().click();
	}

}
