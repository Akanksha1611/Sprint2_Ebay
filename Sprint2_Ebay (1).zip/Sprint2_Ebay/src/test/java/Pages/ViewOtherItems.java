package Pages;

public class ViewOtherItems {
	public static void click_ViewCancel()
	{
		locaters.Locaters.clickViewItem().click();
	}

}
