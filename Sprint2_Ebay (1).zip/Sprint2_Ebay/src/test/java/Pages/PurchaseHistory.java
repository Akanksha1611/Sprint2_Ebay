package Pages;

public class PurchaseHistory {
	public static void getPurchaseHistory()
	{
		locaters.Locaters.myEbay();
		
	}

}
