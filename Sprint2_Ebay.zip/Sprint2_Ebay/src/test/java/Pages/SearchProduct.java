package Pages;

public class SearchProduct {

	public static void enter_ProductName()
	{
		//locaters.Locaters.enterPro_Name().sendKeys("Mobile");
		//.enterPro_Name().sendkeys(ReadData.readExcel(0,0));
	
	
	}
	public static void click_Search()
	{
		locaters.Locaters.clickSearch().click();
		
	}
}
